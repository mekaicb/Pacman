// APSC 142 Engineering Programming Project Starter Code
// Copyright Sean Kauffman 2024

#include "defines.h"
#include "actor.h"
#include "map.h"   // included for is_wall

extern char * map, * dot_map;
extern int height;
extern int width;

char sees_player(int player_y, int player_x, int ghost_y, int ghost_x) {
    // check to see if the ghost is eating the player
    // check if neither the x nor y coordinate is the same as the player
    // if one of them is the same, check if the path in between is clear
    // if there's a wall in between, they can't see

    return SEES_NOTHING;
}

int move_player(int * y, int * x, char direction) {
    // check for an invalid direction (not LEFT, RIGHT, UP, or DOWN)
    if (direction != LEFT && direction != RIGHT && direction != UP && direction != DOWN){ //all conditions must be true at same time
        return MOVED_INVALID_DIRECTION;
    }
    // calculate the new coordinates to use on success (store in local variables)
    int new_x = *x, new_y = *y;

    // check if the new coordinates point to an inner wall & update new coordinates
    switch (direction) {
        //player moving left
        case LEFT:
            if (map[*y *width +(*x-1)] == WALL){ //check if wall in inner maps bounds
                return MOVED_WALL;
            }else{
                new_x--; //set the new value for x
            }break;

        //player moving right
        case RIGHT:
            if (map[*y *width +(*x+1)] == WALL){ //check if wall in inner maps bounds
                return MOVED_WALL;
            }else{
                new_x++; //set the new value for x
            }break;

        //player moving up
        case UP:
            if (map[(*y-1) *width + *x] == WALL){ //check if wall in inner maps bounds
                return MOVED_WALL;
            }else{
                new_y--; //set the new value for y
            }break;

        //player moving down
        case DOWN:
            if (map[(*y+1) *width +*x] == WALL){ //check if wall in inner maps bounds
                return MOVED_WALL;
            }else{
                new_y++; //set the new value for y
            }break;
    }
    //check if the new coordinates point outside the map (also a wall)
    if (new_x < 0 || new_y < 0 || new_y >= height || new_x >= width){
        return MOVED_WALL;
    }

    // at this point, the move is known to be valid (OK direction and not a wall)
    // remove player from the old position and replace with EMPTY
    map[*y *width + *x] = EMPTY;

    // set PLAYER in the new position in map
    map[new_y*width+new_x] = PLAYER;

    // set EMPTY in the new position in dot_map
    dot_map[new_y*width+ new_x] = EMPTY;
    // update the x/y coordinate pointers
    *x = new_x;
    *y = new_y;

    return MOVED_OKAY;
}

int move_ghost(int * y, int * x, char direction) {
    // check for an invalid direction (not LEFT, RIGHT, UP, or DOWN)
    // calculate the new coordinates to use on success (store in local variables)
    // check if the new coordinates point to a wall
    // check if the new coordinates point outside the map (also a wall)

    // at this point, the move is known to be valid (OK direction and not a wall)
    // get the value from the old position in the dot_map (either EMPTY or DOT)
    // remove ghost from the old position and replace with what was in dot_map
    // set GHOST in the new position in map
    // update the x/y coordinate pointers

    return MOVED_OKAY;
}
