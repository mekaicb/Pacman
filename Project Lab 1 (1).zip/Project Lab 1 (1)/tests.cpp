// APSC 142 Engineering Programming Project Starter Code
// Copyright Sean Kauffman 2024

#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include <stdio.h>

// make sure not to modify anything in this extern block
extern "C"{
#include "defines.h"
#include "map.h"
#include "actor.h"
#include "game.h"
char *map = NULL, *dot_map = NULL;
int width, height;
}

/**
 * This file is where you should put your tests for your code.
 * Your code must have tests that execute at least 85% of the code in
 * required functions for you to get full marks for the project.
 * Make sure to check out the course videos on automated testing for
 * more information about how to write tests.
 */

/* tests for map.c */
TEST_SUITE_BEGIN("Map tests");

// tests for load_map
TEST_CASE("A test for load_map") {
    CHECK(0 == 0);
}

// tests for is_wall

TEST_SUITE_END();

/* tests for actor.c */
TEST_SUITE_BEGIN("Actor tests");

// tests for sees_player
TEST_CASE("Testing sees_player") {
    CHECK((sees_player(0,0,0,0))==EATING_PLAYER);
    CHECK((sees_player(1,0,0,0))==DOWN);
    CHECK((sees_player(0,1,0,0))== RIGHT);
    CHECK((sees_player(0,0,1,0))==UP);
    CHECK((sees_player(0,0,0,1))==LEFT);
    CHECK((sees_player(0,0,1,3))==SEES_NOTHING);//not same row or col
    CHECK((sees_player(0,7,1,8))==SEES_NOTHING);

    char tiny_map[] = {WALL, DOT, PLAYER, WALL,
                       GHOST, WALL};
    map = tiny_map;

    CHECK((sees_player(0,2,0,4))==SEES_NOTHING); //wall in between

    char tiny_map1[] = {WALL, DOT, GHOST, WALL,
                       PLAYER, WALL};
    map = tiny_map1;
    CHECK((sees_player(0,4,0,2))==SEES_NOTHING); //wall in between


    char tiny_map2[3][4] = {WALL, DOT, GHOST, WALL,
                        WALL, DOT, WALL,  WALL,
                        WALL, DOT, PLAYER, WALL};
    map = *tiny_map2;
    CHECK((sees_player(2,2,0,2))==SEES_NOTHING); //wall in between


}


// tests for move_player
TEST_CASE("Testing Move_Player"){
    int player_y = 0, player_x = 0;

    char tiny_map[] = {WALL, DOT, PLAYER, DOT,
                       DOT, WALL};
    map = tiny_map;
    height = 2;
    width = 2;
    char tiny_dot_map[] = {WALL, DOT, EMPTY, DOT,
                           DOT, WALL};
    dot_map = tiny_dot_map;

    char direction = RIGHT;
    CHECK(move_player(&player_y,&player_x,direction)==MOVED_OKAY);
    CHECK(move_player(&player_y,&player_x,direction)==MOVED_WALL);

    char dir = UP;
    CHECK(move_player(&player_y,&player_x,dir)==MOVED_WALL);
    CHECK(move_player(&player_y,&player_x,dir)==MOVED_WALL);

    char direc = LEFT;
    CHECK(move_player(&player_y,&player_x,direc)==MOVED_OKAY);
    CHECK(move_player(&player_y,&player_x,direc)==MOVED_WALL);

    char direct = DOWN;
    CHECK(move_player(&player_y,&player_x,direct)==MOVED_OKAY);
    CHECK(move_player(&player_y,&player_x,direct)==MOVED_WALL);


    int y = 0, x = 0;

    char tiny_map1[] = {PLAYER, DOT, DOT,
                       DOT, WALL};
    map = tiny_map1;
    height = 2;
    width = 2;
    char tiny_dot_map1[] = { EMPTY, DOT, DOT,
                           DOT, WALL};
    dot_map = tiny_dot_map1;

    char direct1 = 't';
    CHECK(move_player(&y,&x,direct1)== MOVED_INVALID_DIRECTION);
}

// tests for move_ghost
TEST_CASE("testing move_ghost") {
    int ghost_y = 0, ghost_x = 3;

    char direct = RIGHT;
    CHECK(move_ghost(&ghost_y,&ghost_x,direct)==MOVED_WALL);

    direct = UP;
    CHECK(move_ghost(&ghost_y,&ghost_x,direct)==MOVED_WALL);

    direct = LEFT;
    CHECK(move_ghost(&ghost_y,&ghost_x,direct)==MOVED_WALL);

    direct = DOWN;
    CHECK(move_ghost(&ghost_y,&ghost_x,direct)==MOVED_WALL);

    direct = 't';
    CHECK(move_ghost(&ghost_y,&ghost_x,direct)== MOVED_INVALID_DIRECTION);

    ghost_y = 0, ghost_x = 0;
    direct = DOWN;
    CHECK(move_ghost(&ghost_y,&ghost_x,direct)==MOVED_OKAY);
}
TEST_SUITE_END();

/* tests for game.c */
TEST_SUITE_BEGIN("Game tests");

// tests for check_win
TEST_CASE("Testing check_win") {
    char dot_map1[] = {EMPTY, EMPTY , EMPTY};
    char dot_map2[] = { EMPTY, DOT, DOT};

    if (dot_map = dot_map1)
        CHECK(check_win()==YOU_WIN);
    if (dot_map = dot_map2)
        CHECK(check_win() == KEEP_GOING);
}

// test for check_loss
TEST_CASE("Testing check_loss") {
    int ghosts_y[NUM_GHOSTS] = {5,6};
    int ghosts_x[NUM_GHOSTS] = {5,6};
    CHECK(check_loss(4, 4, ghosts_y, ghosts_x) == KEEP_GOING);
    CHECK(check_loss(4, 5, ghosts_y, ghosts_x) == KEEP_GOING);
    CHECK(check_loss(4, 6, ghosts_y, ghosts_x) == KEEP_GOING);
    CHECK(check_loss(5, 4, ghosts_y, ghosts_x) == KEEP_GOING);
    CHECK(check_loss(5, 5, ghosts_y, ghosts_x) == YOU_LOSE);
    CHECK(check_loss(5, 6, ghosts_y, ghosts_x) == KEEP_GOING);
    CHECK(check_loss(5, 7, ghosts_y, ghosts_x) == KEEP_GOING);
    CHECK(check_loss(6, 4, ghosts_y, ghosts_x) == KEEP_GOING);
    CHECK(check_loss(6, 5, ghosts_y, ghosts_x) == KEEP_GOING);
    CHECK(check_loss(6, 6, ghosts_y, ghosts_x) == YOU_LOSE);
    CHECK(check_loss(6, 7, ghosts_y, ghosts_x) == KEEP_GOING);
    CHECK(check_loss(7, 5, ghosts_y, ghosts_x) == KEEP_GOING);
    CHECK(check_loss(7, 6, ghosts_y, ghosts_x) == KEEP_GOING);
    CHECK(check_loss(7, 7, ghosts_y, ghosts_x) == KEEP_GOING);

    CHECK(check_loss(1, 1, ghosts_y, ghosts_x) == KEEP_GOING);

}

TEST_SUITE_END();