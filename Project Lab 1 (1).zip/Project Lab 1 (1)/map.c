// APSC 142 Engineering Programming Project Starter Code
// Copyright Sean Kauffman 2024

#include <stdio.h>
#include <stdlib.h> //added this

#include "defines.h"
#include "colours.h"
#include "map.h"



extern char *map, *dot_map;
extern int width, height;

/**
 * You should use this function to print out individual characters
 * in the colours used in the demo.
 * @param c
 */
static void printc(char c) {
    switch (c) {
        case WALL:
            change_text_colour(BLUE);
            break;
        case GHOST:
            change_text_colour(PINK);
            break;
        case PLAYER:
            change_text_colour(YELLOW);
            break;
        case DOT:
            change_text_colour(WHITE);
            break;
        default:
            change_text_colour(WHITE);
    }
    printf("%c", c);
}

void print_map(void) {
    int counter = 0;
    char mapArray[9][9];
    //print the outer top wall layer
    printc(WALL);
    for (int i = 0; i < 9 +1;i++){
        printf(" ");
        printc(WALL);
    } printf("\n");
    //print the inside of the map
    for (int y = 0; y < 9; y++){
        printc(WALL); //print outer left wall
        for (int x = 0; x < 9; x++ ){
            mapArray[y][x] = map[counter];
            char c = mapArray [y][x];
            printf(" ");
            printc(c);
            counter++;
        }
        printf(" ");
        printc(WALL); //print outer right wall
        printf("\n");
    }
    //print the bottom outer wall layer
    printc(WALL);
    for (int i = 0; i < 9 +1;i++){
        printf(" ");
        printc(WALL);
    }
    printf("\n");
}

int is_wall(int y, int x) {
    return NOT_WALL;
}

char * load_map(char * filename, int *map_height, int *map_width) {
//    FILE *fp;
//    fp = fopen(filename,"r");
//
//    if (fp == NULL){
//        printf("File not Found");
//        return NULL;
//    }

    return NULL;
}
