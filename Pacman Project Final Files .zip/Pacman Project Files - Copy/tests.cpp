// APSC 142 Engineering Programming Project Starter Code
// Copyright Sean Kauffman 2024

#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include <stdio.h>

// make sure not to modify anything in this extern block
extern "C"{
#include "defines.h"
#include "map.h"
#include "actor.h"
#include "game.h"
char *map = NULL, *dot_map = NULL;
int width, height;
}

/**
 * This file is where you should put your tests for your code.
 * Your code must have tests that execute at least 85% of the code in
 * required functions for you to get full marks for the project.
 * Make sure to check out the course videos on automated testing for
 * more information about how to write tests.
 */

/* tests for map.c */
TEST_SUITE_BEGIN("Map tests");

// tests for load_map
TEST_CASE("A test for load_map") {
    //assigns a variable to the text file
    char filename []= "map3.txt";
    //assigns global variable map to the function
    map = load_map(filename,&height, &width);
    //checks if the height and width product is accurate
    CHECK((height * width) == 45);

    free(map);

    //tests case where file does not exist
    char filename1 [] = "butterscotch.txt";
    map = load_map(filename1,&height, &width);
    CHECK( map == NULL);
}

// tests for is_wall
TEST_CASE("Testing is_wall") {
    //create a small map
    char tiny_map[] = {WALL, DOT, PLAYER, DOT,
                       DOT, WALL};
    //assign the map to the global variable
    map = tiny_map;
    //assigns values of the width and height
    width = 3;
    height = 2;

    //wall coordinate tests
    CHECK(is_wall(0,0)== YES_WALL);//tests wall coordinate
    CHECK(is_wall(1,1)== NOT_WALL);//tests wall coordinate

    //not wall coordinate tests
    CHECK(is_wall(0,1)== NOT_WALL);//tests not wall coordinate
    CHECK(is_wall(0,2)== NOT_WALL);//tests player coordinate
    CHECK(is_wall(1,0)== NOT_WALL);//tests dot coordinate

    //out of bounds coordinate tests
    CHECK(is_wall(-1,0) == YES_WALL); //test negative y
    CHECK(is_wall(0,-1)== YES_WALL);//test negative x
    CHECK(is_wall(45,0)==YES_WALL);//tests out of bound y
    CHECK(is_wall(0,10)==YES_WALL);//tests out of bound x
    CHECK(is_wall(30, 12)== YES_WALL); //both out of bound

}
TEST_SUITE_END();

/* tests for actor.c */
TEST_SUITE_BEGIN("Actor tests");

// tests for sees_player
TEST_CASE("Testing sees_player") {
    //test case where ghost and player are on same coordinate
    CHECK((sees_player(0,0,0,0))==EATING_PLAYER);

    //test case where player is below ghost
    CHECK((sees_player(1,0,0,0))==DOWN);

    //test case player is to the right of the ghost
    CHECK((sees_player(0,1,0,0))== RIGHT);

    //test case player is above the ghost
    CHECK((sees_player(0,0,1,0))==UP);

    //test case player is to the left of the ghost
    CHECK((sees_player(0,0,0,1))==LEFT);

    //test case where the player and ghosts are not in same rows or columns
    CHECK((sees_player(0,0,1,3))==SEES_NOTHING);//not same row or col
    CHECK((sees_player(0,7,1,8))==SEES_NOTHING);

    //create another small map
    char tiny_map[] = {WALL, DOT, PLAYER, WALL,
                       GHOST, WALL};
    map = tiny_map;
    //test if ghost sees nothing with a wall in between player and ghost
    CHECK((sees_player(0,2,0,4))==SEES_NOTHING); //wall in between

    char tiny_map1[] = {WALL, DOT, GHOST, WALL,
                       PLAYER, WALL};
    map = tiny_map1;
    //test if ghost sees nothing with a wall in between player and ghost
    CHECK((sees_player(0,4,0,2))==SEES_NOTHING); //wall in between


    char tiny_map2[] = {WALL, DOT, GHOST, WALL,
                        WALL, DOT, WALL,  WALL,
                        WALL, DOT, PLAYER, WALL};
    map = tiny_map2;
    width = 4;
    height = 3;
    //test with vertical wall in between player and ghost
    CHECK((sees_player(2,2,0,2))==SEES_NOTHING); //wall in between
}


// tests for move_player
TEST_CASE("Testing Move_Player"){
    int player_y = 0, player_x = 0;

    //create a small map
    char tiny_map[] = {WALL, DOT, PLAYER, DOT,
                       DOT, WALL};
    map = tiny_map;
    //assign the height and width
    height = 2;
    width = 2;
    //create a small dot map
    char tiny_dot_map[] = {WALL, DOT, EMPTY, DOT,
                           DOT, WALL};
    dot_map = tiny_dot_map;

    //test player moving right
    char direction = RIGHT;
    CHECK(move_player(&player_y,&player_x,direction)==MOVED_OKAY);
    CHECK(move_player(&player_y,&player_x,direction)==MOVED_WALL);

    //test player moving up
    char dir = UP;
    CHECK(move_player(&player_y,&player_x,dir)==MOVED_WALL);
    CHECK(move_player(&player_y,&player_x,dir)==MOVED_WALL);

    //test player moving left
    char direc = LEFT;
    CHECK(move_player(&player_y,&player_x,direc)==MOVED_OKAY);
    CHECK(move_player(&player_y,&player_x,direc)==MOVED_WALL);

    //test player moving down
    char direct = DOWN;
    CHECK(move_player(&player_y,&player_x,direct)==MOVED_OKAY);
    CHECK(move_player(&player_y,&player_x,direct)==MOVED_WALL);


    int y = 0, x = 0;
    //create a new small map
    char tiny_map1[] = {PLAYER, DOT, DOT,
                       DOT, WALL};
    map = tiny_map1;
    //reassign height and width
    height = 2;
    width = 2;
    char tiny_dot_map1[] = { EMPTY, DOT, DOT,
                           DOT, WALL};
    dot_map = tiny_dot_map1;

    //test invalid direction
    char direct1 = 't';
    CHECK(move_player(&y,&x,direct1)== MOVED_INVALID_DIRECTION);
}

// tests for move_ghost
TEST_CASE("testing move_ghost") {
    int ghost_y = 0, ghost_x = 3;
    //test ghost moving right
    char direct = RIGHT;
    CHECK(move_ghost(&ghost_y,&ghost_x,direct)==MOVED_WALL);
    //test ghost moving up
    direct = UP;
    CHECK(move_ghost(&ghost_y,&ghost_x,direct)==MOVED_WALL);
    //test ghost moving left
    direct = LEFT;
    CHECK(move_ghost(&ghost_y,&ghost_x,direct)==MOVED_WALL);
    //test ghost moving down
    direct = DOWN;
    CHECK(move_ghost(&ghost_y,&ghost_x,direct)==MOVED_WALL);
    //test invalid direction
    direct = 't';
    CHECK(move_ghost(&ghost_y,&ghost_x,direct)== MOVED_INVALID_DIRECTION);

    ghost_y = 0, ghost_x = 0;
    //test ghost moving down
    direct = DOWN;
    CHECK(move_ghost(&ghost_y,&ghost_x,direct)==MOVED_OKAY);
}
TEST_SUITE_END();

/* tests for game.c */
TEST_SUITE_BEGIN("Game tests");

// tests for check_win
TEST_CASE("Testing check_win") {
    //create an empty dot map
    char dot_map1[] = {EMPTY, EMPTY , EMPTY};
    //create a dot map with some dots
    char dot_map2[] = { EMPTY, DOT, DOT};
    //assign height and width
    width = 3;
    height = 1;
    //check function with an empty dot map
    dot_map = dot_map1;
    CHECK(check_win() == YOU_WIN);
    //check function with a not empty map
    dot_map = dot_map2;
    CHECK(check_win() == KEEP_GOING);
}

// test for check_loss
TEST_CASE("Testing check_loss") {
    //set ghost positions
    int ghosts_y[NUM_GHOSTS] = {5,6};
    int ghosts_x[NUM_GHOSTS] = {5,6};

    //check if player and ghost are in the same position and outputs result
    CHECK(check_loss(4, 4, ghosts_y, ghosts_x) == KEEP_GOING);
    CHECK(check_loss(5, 5, ghosts_y, ghosts_x) == YOU_LOSE);
}

TEST_SUITE_END();