// APSC 142 Engineering Programming Project Starter Code
// Copyright Sean Kauffman 2024

#include <stdio.h>
#include <stdlib.h> //added this

#include "defines.h"
#include "colours.h"
#include "map.h"

extern char *map, *dot_map;
extern int width, height;

/**
 * You should use this function to print out individual characters
 * in the colours used in the demo.
 * @param c
 */
static void printc(char c) {
    switch (c) {
        case WALL:
            change_text_colour(BLUE);
            break;
        case GHOST:
            change_text_colour(PINK);
            break;
        case PLAYER:
            change_text_colour(YELLOW);
            break;
        case DOT:
            change_text_colour(WHITE);
            break;
        default:
            change_text_colour(WHITE);
    }
    printf("%c", c);
}

void print_map(void) {
    //print the outer top wall layer
    printc(WALL);
    for (int i = 0; i < width +1;i++){
        printf(" ");
        printc(WALL);
    } printf("\n");

    //print the inside of the map
    for (int y = 0; y < height; y++){
        printc(WALL); //print outer left wall
        for (int x = 0; x < width; x++ ){
            char c = map[y*width +x];
            printf(" ");
            printc(c);
        }
        printf(" ");
        printc(WALL); //print outer right wall
        printf("\n");
    }

    //print the bottom outer wall layer
    printc(WALL);
    for (int i = 0; i < width +1;i++){
        printf(" ");
        printc(WALL);
    }
    printf("\n");
}

int is_wall(int y, int x) {
    //find the map coordinate that needs a wall check
    int coordinate = y*width + x;
    //if that coordinate is a wall, return yes wall
    if (map[coordinate] == WALL){
        return YES_WALL;
    }
    //if the coordinate y and x are out of map bounds, return yes wall
    else if (y >= height || x >= width || y < 0 || x < 0){
        return YES_WALL;
    }
    //if none of above is true, return not a wall
    return NOT_WALL;
}

char * load_map(char * filename, int *map_height, int *map_width) {
    FILE *fp;
    int heightY = 1, widthX = 0, widthCount = 0; //height starts at 1 since the first row does not have a '\n' for it
    char temp;
    //open file and read file
    fp = fopen(filename, "r");

    //if file fails to open, return null
    if (fp == NULL) {
        return NULL;
    }

    //get map dimensions
    int counter = 0;
    while (fscanf(fp, "%c", &temp) ==1){
        if (temp == '\n') { //if the character is a new line
            heightY++;//update height count
            if (widthX == 0) {
                widthX = widthCount; //update column count based on 1st row
            }
            widthCount = 0; //reset width count for the next row
            counter = 0;
        }else {
            if (counter % 3 == 0) //count every 3rd character
                widthCount++;
        }
        counter++;
    }
    //close file
    fclose(fp);

    //allocate memory for map
    map = (char *) malloc(widthX * heightY * sizeof(char));
    if (map == NULL) {
        return NULL;
    }

    //reread map file content
    fp = fopen(filename, "r");
    if (fp == NULL) {
        free(map);  // Free memory if no file
        return NULL;
    }
    //set the map content to the "map" array
    int index = 0;
    counter = 0;
    while (fscanf(fp, "%c", &temp) == 1 && index<widthX*heightY){
        if (temp != '\n') { //if the character is a new line
            if (counter % 3 ==0) { //if the counter is at the "3rd" characters
                map[index++] = temp; //assign map index to the character
            }
            counter ++;
        }
        else {
            counter = 0; //reset counter
        }
    }

    //close file
    fclose(fp);

    //set variable values
    *map_width = widthX;
    *map_height = heightY;

    return map;
}
