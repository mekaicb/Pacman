// APSC 142 Engineering Programming Project Starter Code
// Copyright Sean Kauffman 2024

#include "defines.h"
#include "game.h"
#include <stdio.h> //added this

extern char * map, * dot_map;
extern int height;
extern int width;

int check_win(void) {
    //loop through the dot map
    for (int i = 0; i < (width*height); i++) {
        //checks if any of the coordinates in the dot map are still "dots"
        if (dot_map[i] == DOT) {
            //if there are still dots, return keep going
            return KEEP_GOING;
        }
    }
    // if no dots left, return you win
    return YOU_WIN;
}

int check_loss(int player_y, int player_x, int ghosts_y[NUM_GHOSTS], int ghosts_x[NUM_GHOSTS]) {
    //loop through ghost  positions
    for (int i = 0; i < NUM_GHOSTS; i++) {
        //if player and ghost coordinates match, return you lose
        if (player_y == ghosts_y[i] && player_x == ghosts_x[i]) {
            return YOU_LOSE;
        }
    }
    //if player and ghost coordinates don't match, return keep going
    return KEEP_GOING;
}
