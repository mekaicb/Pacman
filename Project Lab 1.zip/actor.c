// APSC 142 Engineering Programming Project Starter Code
// Copyright Sean Kauffman 2024

#include "defines.h"
#include "actor.h"

char sees_player(int player_y, int player_x, int ghost_y, int ghost_x) {
    return SEES_NOTHING;
}

int move_player(int * y, int * x, char direction) {
    return MOVED_OKAY;
}

int move_ghost(int * y, int * x, char direction) {
    return MOVED_OKAY;
}
